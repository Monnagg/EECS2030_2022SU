package eecs2030.lab6;

public enum CardSuit {
}
