package eecs2030.lab6;

/**
 * This class implements poker game-related methods
 * @author 
 *
 */
public class Poker {
	private Poker(){};

	/**
	 * Checks if a hand contains a Three of a kind: https://en.wikipedia.org/wiki/List_of_poker_hands#Three_of_a_kind
	 * @param hand
	 * @return true if the hand contains three cards of one rank and two cards of two other ranks 
	 * NOTE: Four of a kind is excluded, https://en.wikipedia.org/wiki/List_of_poker_hands#Four_of_a_kind; 
	 * so is Full House: three cards of one rank and two cards of another rank)
	 * 
	 */
	public static boolean hasThreeOfAKind(PokerHand hand){
		//TODO
		return false;
	}

	/**
	 * Checks if a hand contains a Flush: https://en.wikipedia.org/wiki/List_of_poker_hands#Flush
	 * @param hand
	 * @return true if the hand contains five cards all of the same suit, not all of sequential rank
	 * NOTE: Straight flush https://en.wikipedia.org/wiki/List_of_poker_hands#Straight_flush  
	 * are to be excluded
	 */
	public static boolean hasFlush(PokerHand hand){
		//TODO
		return false;
	}

}
