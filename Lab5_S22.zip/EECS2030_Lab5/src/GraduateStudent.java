import java.util.Date;

public class GraduateStudent extends Student{
}
