import java.util.Date;

public class SalariedEmployee extends Employee {
}
