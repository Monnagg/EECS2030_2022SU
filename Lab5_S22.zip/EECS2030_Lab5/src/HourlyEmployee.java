import java.util.Date;

public class HourlyEmployee extends Employee {
}
